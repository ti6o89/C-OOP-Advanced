﻿
namespace _3.Generic_Scale
{
    class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
